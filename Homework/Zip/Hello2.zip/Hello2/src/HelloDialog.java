/*Filename HelloDialog.java
 * Written by Wilman Garcia
 * Assignment: HW1
 * Written on 2/16/2017
 */

import javax.swing.JOptionPane;

public class HelloDialog {
	
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null,"Hello, World!");
	}
}
