/*Filename Hello2.java
 * Written by Wilman Garcia
 * Assignment: HW1
 * Written on 2/16/2017
 */

public class Hello2 /*This class demonstrates the use of the println()
method to print the message Hello World!*/
{
	public static void main(String[] args)
	{
		System.out.println("Hello Wolrd!");
	}
}
